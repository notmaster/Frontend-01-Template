var parser = require('./parser')

parser.parseHTML(`
<script></script>
`)